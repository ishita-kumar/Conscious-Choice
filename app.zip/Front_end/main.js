
// window.onload = function () {
//   document.getElementById("Div1").onclick = switchVisible;
   // closepopup
//   const closed = document.getElementById("close");
 
//   closed.addEventListener("click", (e) => {
//     e.preventDefault();
//     window.close();
//   });
// };

// function switchVisible() {
//   document.getElementById("Div2").style.display = "block";
//   document.getElementById("Div1").innerHTML = "Trail";
// }


