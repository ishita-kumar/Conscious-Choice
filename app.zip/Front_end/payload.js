
chrome.runtime.sendMessage(document.title);